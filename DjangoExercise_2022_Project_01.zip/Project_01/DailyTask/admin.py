from django.contrib import admin
from . import models


class UserDailyTasksAdmin(admin.ModelAdmin):
    list_display = ('task_title', 'tak_start_datetime',
                    'task_expire_date', 'task_active')


admin.site.register(models.UserDailyTasks, UserDailyTasksAdmin)
