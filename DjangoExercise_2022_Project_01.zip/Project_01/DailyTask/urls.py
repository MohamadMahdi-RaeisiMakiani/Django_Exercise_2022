from django.urls import path
from . import views

urlpatterns = [
    path('taskall', views.ShowAllTasksView.as_view(), name='alltasks.show'),
    path('acttask', views.TaskActionView.as_view(), name='actiontask.show'),
    path('addtask', views.TaskCreateView.as_view(), name='addtask.show'),
    path('taskall/<int:pk>', views.ShowEveryTaskView.as_view(),
         name='everytask.show'),
    path('taskall/<int:pk>/updatetask',
         views.TaskUpdateView.as_view(), name='updatetask.show'),
    path('taskall/<int:pk>/deltask',
         views.DeleteTaskView.as_view(), name='deltask.show'),
]
