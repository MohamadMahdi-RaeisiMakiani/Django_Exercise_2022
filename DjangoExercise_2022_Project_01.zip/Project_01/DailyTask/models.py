from django.db import models
from datetime import datetime


class UserDailyTasks(models.Model):
    task_title = models.CharField(max_length=200)
    task_description = models.TextField()
    tak_start_datetime = datetime.today()
    task_expire_date = models.DateTimeField()
    task_active = models.BooleanField()
