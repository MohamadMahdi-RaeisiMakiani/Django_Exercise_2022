from django.shortcuts import render
from django.views.generic import TemplateView, DetailView, ListView, CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import DeleteView
from .models import UserDailyTasks
from .forms import UserDailyTasksForm


class TaskActionView(TemplateView):
    template_name = 'DailyTask_HtmlTemplates/ActionTaskPage.html'


class ShowAllTasksView(ListView):
    model = UserDailyTasks
    context_object_name = 'AllTasks_tmp'
    template_name = 'DailyTask_HtmlTemplates/UserAllTasksPage.html'


class ShowEveryTaskView(DetailView):
    model = UserDailyTasks
    context_object_name = 'EachTask_tmp'
    template_name = 'DailyTask_HtmlTemplates/UserEveryTaskPage.html'


class DeleteTaskView(DeleteView):
    model = UserDailyTasks
    # html form action
    success_url = '/taskall'
    context_object_name = 'delobject_1'
    template_name = 'DailyTask_HtmlTemplates/DeleteTaskPage.html'


class TaskUpdateView(UpdateView):
    model = UserDailyTasks
    success_url = '/taskall'
    form_class = UserDailyTasksForm
    context_object_name = 'upobject_1'
    template_name = 'DailyTask_HtmlTemplates/UpdateTaskPage.html'


class TaskCreateView(CreateView):
    model = UserDailyTasks
    form_class = UserDailyTasksForm
    success_url = '/taskall'
    template_name = 'DailyTask_HtmlTemplates/CreateTaskPage.html'
