from django import forms
from django.core.exceptions import ValidationError
from .models import UserDailyTasks


class UserDailyTasksForm(forms.ModelForm):
    class Meta:
        model = UserDailyTasks
        start = forms.DateTimeField(input_formats=['%Y-%m-%dT%H:%M'])

        fields = ('task_title', 'task_description',
                  'task_expire_date', 'task_active')
        widgets = {
            'task_title': forms.TextInput(attrs={'class': 'task-title_input'}),
            'task_description': forms.Textarea(attrs={'class': 'task-full_input'}),
            'task_expire_date': forms.DateTimeInput(attrs={'class': 'task-expire_input', 'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
            'task_active': forms.CheckboxInput(attrs={'class': 'task-status_input'}),

        }
        labels = {
            'task_title': 'Enter the task title',
            'task_description': 'Tell more about the task',
            'task_expire_date': 'Choose your expire datetime',
            'task_active': 'Is it done or not?',
        }

    def clean_title(self):
        # title = self.cleaned_data['task_title']
        # if 'Task' not in title:
        #     raise ValidationError('Please use -Task- in your title')
        # return title
        pass
