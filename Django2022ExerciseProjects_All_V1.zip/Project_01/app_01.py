def main():
    print("Hello, World!")
    print("integratedTerminal")
    print("internalConsole")
    print("Next commit")


main()
